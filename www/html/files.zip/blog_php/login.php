<?php
	
	$hn = 'localhost';
	$db = 'blog';
	$un = 'username';
	$pw = 'password';

?>