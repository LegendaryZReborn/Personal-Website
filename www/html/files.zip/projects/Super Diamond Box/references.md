http://www.html5gamedevs.com/topic/4939-how-to-remove-gametimeeventsloop/

	-game.time.events.stop();
	
	
http://www.html5gamedevs.com/topic/7447-use-both-arrow-keys-and-wasd-controls/